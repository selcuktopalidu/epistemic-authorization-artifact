# Epistemic authorization for AI agents — artifact

Reference implementation and experiments for

> S. Topal, *Epistemic authorization for AI agents: knowing enough to act under bounded stale evidence*, submitted to the International Journal of Approximate Reasoning.

An AI agent may act only if its monotone authority policy holds in **every** source state consistent with its evidence and a bound `k` on unobserved revocations. The kernel decides this judgment (Permit / Defer / Deny), computes the minimal dangerous cuts, plans minimum-cost refreshes, and runs the adaptive observation loop.

## Layout

```
src/
  authority.py            kernel: circuits, worlds, cuts, radius, verdicts,
                          exact/greedy refresh, compositional shortcut,
                          adaptive verification, AtomicGate
  generators.py           seeded circuit generators (E1, E2, vertex-cover family)
  run_experiments.py      E1, E2, graph family, E4, atomic-gate schedule
  adaptive_experiment.py  E3 adaptive sample and ablation sample
  analyze.py              bootstrap intervals, summary.json, figures
tests/test_authority.py   8 focused unit tests
public_source/            AgentDojo v1 user_tasks.py files at a pinned commit,
                          their MIT license, and MANIFEST.txt with SHA-256 hashes
results/                  raw CSV outputs and summary.json
figures/                  fig_cost_approx.pdf, fig_timing_falsesafe.pdf
```

## Reproduce

Python 3.10 or newer. The kernel and experiment drivers use only the standard library; `analyze.py` needs `pip install -r requirements.txt`.

```
python3 -m unittest discover -s tests -v
python3 src/run_experiments.py      # ~2 s
python3 src/adaptive_experiment.py  # ~20 s
python3 src/analyze.py
```

All seeds are fixed, so every number in `results/summary.json` is reproduced exactly. Wall-clock timings (`cut_ms`, `opt_ms`) vary between machines and runs.

## Minimal example

```python
from authority import Circuit, minimal_cuts, optimal_refresh, robust
c = Circuit(["owner", "delegate_a", "delegate_b"])
d = c.add((1, 2), threshold=1)          # delegate_a OR delegate_b
c.add((0, d), threshold=2)              # owner AND delegation
cuts, _ = minimal_cuts(c, k=1)          # [{owner}]
h = optimal_refresh(cuts, costs=[4, 2, 3])
assert h == frozenset({0})
assert robust(c, k=1, confirmed=h)
```

## Experiments

| ID | What | Output |
|---|---|---|
| E1 | 180 random circuits (n = 4…9): iterative vs. recursive evaluation on all assignments, 720 modal decisions vs. brute force, 50 refresh problems vs. exhaustive optimum, refresh/cut duality on all 128 confirmation sets of 30 seven-source circuits | `e1_checks.csv` |
| E2 | 160 joint-authority policies (n ∈ {8,12,16,24}) × k ∈ {1,2,3}: cut families, optimal and greedy refresh, independence shortcut, timings | `e2_policies.csv` |
| E3 | 10 simulated worlds per E2 condition with actual replies to the adaptive verifier; separate 20-world ablation sample | `e3_adaptive.csv`, `e3_ablation.csv` |
| Graph | 120 random graphs: k = 2 cuts equal edges; greedy vs. optimal vertex cover | `graph_family.csv` |
| E4 | FunctionCall sites in ground_truth methods of AgentDojo v1 user tasks; eight-domain policy overlay on mutating sites | `e4_sites.csv`, `e4_summary.csv` |
| Gate | 100 repetitions of an ordered revoke-before-effect schedule | `atomic_gate.csv` |

## License

MIT (see `LICENSE`). Files in `public_source/` are © the AgentDojo authors, MIT license.
