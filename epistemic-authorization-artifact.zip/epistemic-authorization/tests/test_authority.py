import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from authority import (AtomicGate, Circuit, Request, adaptive_verify,  # noqa: E402
                       compositional_radius, greedy_refresh, knows, minimal_cuts,
                       optimal_refresh, radius, robust, shortcut_robust,
                       source_disjoint, verdict)


def share_policy():
    """Running example C_share = u & s & (d1 | d2); domains u=0,s=1,d1=2,d2=3."""
    c = Circuit(["u", "s", "d1", "d2"])
    d = c.add((2, 3), 1)
    c.add((0, 1, d), 3)
    return c


class TestKernel(unittest.TestCase):
    def test_paper_listing(self):
        c = Circuit(["owner", "delegate_a", "delegate_b"])
        d = c.add((1, 2), threshold=1)
        c.add((0, d), threshold=2)
        cuts, _ = minimal_cuts(c, k=1)
        h = optimal_refresh(cuts, costs=[4, 2, 3])
        self.assertEqual(h, frozenset({0}))
        self.assertTrue(robust(c, k=1, confirmed=h))

    def test_running_example_verdicts(self):
        c = share_policy()
        T = {0, 1}
        self.assertEqual(verdict(c, 1, confirmed=T), "PERMIT")
        self.assertEqual(verdict(c, 2, confirmed=T), "DEFER")
        self.assertEqual(radius(c, confirmed=T), 2)
        self.assertEqual(minimal_cuts(c, 2, confirmed=T)[0], [frozenset({2, 3})])
        self.assertEqual(verdict(c, 2, confirmed=T | {2}), "PERMIT")
        self.assertEqual(verdict(c, 0, invalid={0}), "DENY")

    def test_shared_source_counterexample(self):
        # (a & b) | (a & c): the shortcut predicts radius 2, the true radius is 1
        c = Circuit(["a", "b", "c"])
        x, y = c.add((0, 1), 2), c.add((0, 2), 2)
        c.add((x, y), 1)
        self.assertFalse(source_disjoint(c))
        self.assertEqual(compositional_radius(c), 2)
        self.assertEqual(radius(c), 1)
        self.assertTrue(shortcut_robust(c, 1, checked=False))   # unsafe ablation
        self.assertFalse(shortcut_robust(c, 1, checked=True))   # checked version

    def test_envelope_violation(self):
        # Thr_2(a,b,c): budget 1 permits, but two actual revocations falsify it
        c = Circuit(["a", "b", "c"])
        c.add((0, 1, 2), 2)
        self.assertTrue(robust(c, 1))
        self.assertFalse(c.evaluate({2}))
        self.assertFalse(robust(c, 2))

    def test_triangle_vertex_cover(self):
        c = Circuit(["r1", "r2", "r3"])
        c.add((0, 1, 2), 2)
        cuts, _ = minimal_cuts(c, 2)
        self.assertEqual(set(cuts), {frozenset(p) for p in [(0, 1), (0, 2), (1, 2)]})
        self.assertEqual(len(optimal_refresh(cuts, [1, 1, 1])), 2)
        self.assertEqual(len(greedy_refresh(cuts, [1, 1, 1])), 2)

    def test_adaptive_matches_full_observation(self):
        c = share_policy()
        costs = [5, 5, 1, 2]
        for revoked in [set(), {2}, {3}, {2, 3}]:
            W = {0, 1, 2, 3} - revoked
            dec, queried, _ = adaptive_verify(c, 2, costs, lambda g: g in W, confirmed={0, 1})
            self.assertEqual(dec, "PERMIT" if c.evaluate(W) else "DENY")
            self.assertNotIn(0, queried)
            self.assertNotIn(1, queried)

    def test_duality_on_running_example(self):
        c = share_policy()
        cuts, _ = minimal_cuts(c, 2)
        for mask in range(16):
            H = {g for g in range(4) if mask >> g & 1}
            self.assertEqual(knows(c, 2, confirmed=H), all(H & D for D in cuts))

    def test_atomic_gate_rejections(self):
        c = share_policy()
        gate = AtomicGate(c, policy_epoch=3, state={g: (True, 0) for g in range(4)})
        a = ("share", "doc", "alice")
        v = gate.snapshot_versions()
        self.assertEqual(gate.accept(Request(("share", "doc", "eve"), 3, v, "n1"), a)[1], "action substitution")
        self.assertEqual(gate.accept(Request(a, 2, v, "n1"), a)[1], "policy epoch changed")
        self.assertTrue(gate.accept(Request(a, 3, v, "n1"), a)[0])
        self.assertEqual(gate.accept(Request(a, 3, v, "n1"), a)[1], "replay")
        gate.revoke(2)
        self.assertEqual(gate.accept(Request(a, 3, v, "n2"), a)[1], "stale source version")


if __name__ == "__main__":
    unittest.main()
