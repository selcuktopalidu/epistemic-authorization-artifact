"""Seeded circuit generators shared by all experiment drivers."""
import random

from authority import Circuit


def random_circuit(n, gates=10, seed=0, max_fanin=4):
    """E1: ``gates`` random threshold gates whose inputs precede them."""
    rng = random.Random(seed)
    c = Circuit(n)
    for _ in range(gates):
        top = c.n + len(c.gates)
        m = rng.randint(1, min(max_fanin, top))
        children = rng.sample(range(top), m)
        c.add(children, rng.randint(1, m))
    return c


def joint_authority_policy(n, seed):
    """E2: conjunction of three approval modules.

    Each module has 3-5 branches, each branch conjoins 1-3 sampled source
    domains, and each module requires one or two branches.  Domains are
    sampled independently, so reuse across branches and modules occurs.
    Returns (circuit, costs) with integer costs uniform on 1..9.
    """
    rng = random.Random(seed)
    c = Circuit(n)
    modules = []
    for _ in range(3):
        branches = []
        for _ in range(rng.randint(3, 5)):
            doms = rng.sample(range(n), rng.randint(1, 3))
            branches.append(c.add(doms, len(doms)))
        modules.append(c.add(branches, rng.randint(1, 2)))
    c.add(modules, 3)
    costs = [rng.randint(1, 9) for _ in range(n)]
    return c, costs


E2_SIZES = (8, 12, 16, 24)
E2_PER_SIZE = 40
BUDGETS = (1, 2, 3)


def e2_policies():
    """The 160 E2 policies, identified by (n, index, seed)."""
    out = []
    for n in E2_SIZES:
        for i in range(E2_PER_SIZE):
            seed = 10_000 * n + i
            c, costs = joint_authority_policy(n, seed)
            out.append((n, i, seed, c, costs))
    return out


def vertex_cover_circuit(n_vertices, edges):
    """Theorem 6.3(b): conjunction of two-input OR gates, one per edge."""
    c = Circuit(n_vertices)
    clauses = [c.add((u, v), 1) for u, v in edges]
    c.add(clauses, len(clauses))
    return c
