"""Experiments E1 (finite-model checks), E2 (synthetic joint-authority
policies), the vertex-cover graph family, E4 (public call-site overlay) and
the atomic-gate revoke-before-effect schedule.

Writes CSV files to ../results/.  Usage:  python3 src/run_experiments.py
"""
import ast
import csv
import os
import random
import time
from itertools import combinations

from authority import (AtomicGate, Circuit, Request, compositional_radius,
                       evaluate_recursive, exhaustive_refresh, greedy_refresh,
                       knows, minimal_cuts, optimal_refresh, robust, verdict,
                       worlds)
from generators import (BUDGETS, e2_policies, random_circuit,
                        vertex_cover_circuit)

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
SRC = os.path.join(HERE, "..", "public_source")
os.makedirs(RES, exist_ok=True)


def write_csv(name, rows):
    path = os.path.join(RES, name)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"  wrote {name} ({len(rows)} rows)")


# ----------------------------------------------------------------------------
# E1
# ----------------------------------------------------------------------------
def e1():
    print("E1: finite-model checks")
    rng = random.Random(1)
    circuits = [(n, s, random_circuit(n, 10, seed=1000 * n + s)) for n in range(4, 10) for s in range(30)]
    rows = []
    # (a) iterative vs recursive evaluation on every assignment
    evals = mism_eval = 0
    for n, s, c in circuits:
        for mask in range(2 ** n):
            X = {i for i in range(n) if mask >> i & 1}
            evals += 1
            mism_eval += c.evaluate(X) != evaluate_recursive(c, X)
    rows.append(dict(check="evaluation", instances=evals, discrepancies=mism_eval))
    # (b) modal decisions: cut-based verdict vs brute-force quantification
    modal = mism_modal = 0
    for n, s, c in circuits:
        for _ in range(4):
            T, F = set(), set()
            for g in range(n):
                u = rng.random()
                if u < 0.25:
                    T.add(g)
                elif u < 0.40:
                    F.add(g)
            k = rng.randint(0, 3)
            ws = list(worlds(c, k, T, F))
            if all(c.evaluate(w) for w in ws):
                truth = "PERMIT"
            elif not any(c.evaluate(w) for w in ws):
                truth = "DENY"
            else:
                truth = "DEFER"
            modal += 1
            mism_modal += verdict(c, k, T, F) != truth
    rows.append(dict(check="modal decisions", instances=modal, discrepancies=mism_modal))
    # (c) exact refresh vs independent exhaustive optimizer
    ref = mism_ref = 0
    seed = 0
    while ref < 50:
        seed += 1
        r = random.Random(seed)
        n = r.randint(5, 8)
        c = random_circuit(n, 10, seed=500_000 + seed)
        k = r.randint(1, 3)
        costs = [r.randint(1, 9) for _ in range(n)]
        cuts, _ = minimal_cuts(c, k)
        if not cuts or frozenset() in cuts:
            continue
        H = optimal_refresh(cuts, costs)
        Hx = exhaustive_refresh(cuts, costs, range(n))
        ref += 1
        cost = lambda S: sum(costs[g] for g in S)
        ok = cost(H) == cost(Hx) and all(set(H) & D for D in cuts)
        mism_ref += not ok
    rows.append(dict(check="refresh optimality", instances=ref, discrepancies=mism_ref))
    # (d) refresh/cut duality on all 128 confirmation sets of 7-source circuits
    dual = mism_dual = 0
    for s in range(30):
        c = random_circuit(7, 10, seed=900_000 + s)
        k = random.Random(s).randint(1, 3)
        cuts, _ = minimal_cuts(c, k)
        for mask in range(128):
            H = {g for g in range(7) if mask >> g & 1}
            lhs = knows(c, k, confirmed=H)
            rhs = all(H & D for D in cuts)
            dual += 1
            mism_dual += lhs != rhs
    rows.append(dict(check="refresh/cut duality", instances=dual, discrepancies=mism_dual))
    write_csv("e1_checks.csv", rows)


# ----------------------------------------------------------------------------
# E2
# ----------------------------------------------------------------------------
def e2():
    print("E2: synthetic joint-authority policies")
    rows = []
    for n, i, seed, c, costs in e2_policies():
        rel = c.relevant()
        total = sum(costs[g] for g in rel)
        for k in BUDGETS:
            t0 = time.perf_counter()
            cuts, nevals = minimal_cuts(c, k, universe=rel)
            t1 = time.perf_counter()
            H = optimal_refresh(cuts, costs)
            t2 = time.perf_counter()
            G = greedy_refresh(cuts, costs)
            ch, cg = sum(costs[g] for g in H), sum(costs[g] for g in G)
            exact_robust = not cuts
            shortcut = compositional_radius(c) > k  # unchecked ablation
            rows.append(dict(
                n=n, index=i, seed=seed, k=k, relevant=len(rel), cuts=len(cuts),
                evaluations=nevals, refresh_all_cost=total, optimal_cost=ch,
                greedy_cost=cg, saving_optimal=1 - ch / total,
                greedy_ratio=(cg / ch) if ch else 1.0,
                exact_robust=int(exact_robust), shortcut_robust=int(shortcut),
                false_safe=int(shortcut and not exact_robust),
                cut_ms=1000 * (t1 - t0), opt_ms=1000 * (t2 - t1)))
    write_csv("e2_policies.csv", rows)


# ----------------------------------------------------------------------------
# Vertex-cover graph family (Theorem 6.3(b))
# ----------------------------------------------------------------------------
def graph_family():
    print("Graph family: k=2 cuts are exactly the edges")
    rows = []
    for s in range(120):
        r = random.Random(70_000 + s)
        nv = r.randint(6, 12)
        edges = [(u, v) for u, v in combinations(range(nv), 2) if r.random() < 0.3]
        if not edges:
            edges = [(0, 1)]
        c = vertex_cover_circuit(nv, edges)
        cuts, _ = minimal_cuts(c, 2)
        edges_ok = set(cuts) == {frozenset(e) for e in edges}
        unit = [1] * nv
        H, G = optimal_refresh(cuts, unit), greedy_refresh(cuts, unit)
        rows.append(dict(instance=s, vertices=nv, edges=len(edges), cuts_equal_edges=int(edges_ok),
                         optimal=len(H), greedy=len(G), ratio=len(G) / len(H)))
    write_csv("graph_family.csv", rows)


# ----------------------------------------------------------------------------
# E4: AgentDojo call-site overlay
# ----------------------------------------------------------------------------
MUTATING = {
    "banking": {"send_money", "schedule_transaction", "update_scheduled_transaction",
                "update_password", "update_user_info"},
    "slack": {"send_direct_message", "send_channel_message", "add_user_to_channel",
              "invite_user_to_slack", "remove_user_from_slack", "post_webpage"},
    "travel": {"reserve_hotel", "reserve_restaurant", "reserve_car_rental", "send_email",
               "create_calendar_event"},
    "workspace": {"send_email", "delete_email", "create_calendar_event",
                  "cancel_calendar_event", "reschedule_calendar_event",
                  "add_calendar_event_participants", "create_file", "append_to_file",
                  "share_file", "delete_file"},
}


def extract_sites(path):
    """Literal FunctionCall(...) nodes inside ground_truth methods of
    explicitly declared UserTask<n> classes."""
    tree = ast.parse(open(path, encoding="utf-8").read())
    classes, sites = 0, []
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name.startswith("UserTask") and node.name[8:].isdigit():
            classes += 1
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name == "ground_truth":
                    for sub in ast.walk(item):
                        if (isinstance(sub, ast.Call) and getattr(sub.func, "id", None) == "FunctionCall"):
                            fn = next((kw.value.value for kw in sub.keywords
                                       if kw.arg == "function" and isinstance(kw.value, ast.Constant)), None)
                            sites.append((node.name, fn))
    return classes, sites


def overlay_policy(reviewer_threshold):
    """Eight domains: owner, scope, endpoint, two alternative delegations,
    three reviewers."""
    c = Circuit(["owner", "scope", "endpoint", "delegation_a", "delegation_b",
                 "reviewer_1", "reviewer_2", "reviewer_3"])
    d = c.add((3, 4), 1)
    rv = c.add((5, 6, 7), reviewer_threshold)
    c.add((0, 1, 2, d, rv), 5)
    return c


def e4():
    print("E4: AgentDojo call-site overlay")
    rows, summary = [], []
    for suite in ("banking", "slack", "travel", "workspace"):
        classes, sites = extract_sites(os.path.join(SRC, f"{suite}_user_tasks.py"))
        mut = [(cls, fn) for cls, fn in sites if fn in MUTATING[suite]]
        thr = 2 if suite == "banking" else 1
        c = overlay_policy(thr)
        rng = random.Random(f"e4-{suite}")
        for j, (cls, fn) in enumerate(mut):
            costs = [rng.randint(1, 9) for _ in range(8)]
            total = sum(costs)
            row = dict(suite=suite, task=cls, function=fn, site=j, refresh_all_cost=total)
            for k in (1, 2):
                cuts, _ = minimal_cuts(c, k)
                H = optimal_refresh(cuts, costs)
                row[f"saving_k{k}"] = 1 - sum(costs[g] for g in H) / total
            rows.append(row)
        summary.append(dict(suite=suite, task_classes=classes, call_sites=len(sites),
                            mutating_sites=len(mut), reviewer_threshold=thr))
    write_csv("e4_sites.csv", rows)
    write_csv("e4_summary.csv", summary)


# ----------------------------------------------------------------------------
# Atomic gate: ordered revoke-before-effect schedule
# ----------------------------------------------------------------------------
def atomic_gate(reps=100):
    print("Atomic gate: revoke-before-effect schedule")
    c = Circuit(["a", "b", "c"])
    c.add((0, 1, 2), 2)  # Thr_2(a, b, c)
    action = ("share", "record-17", "recipient-4")
    unchecked = gated = 0
    for rep in range(reps):
        gate = AtomicGate(c, policy_epoch=1, state={g: (True, 0) for g in range(3)})
        versions = gate.snapshot_versions()
        decided = verdict(c, 0, confirmed={0, 1, 2}) == "PERMIT"  # decision on fresh evidence
        gate.revoke(0)
        gate.revoke(1)  # two revocations between decision and effect
        current = {g for g, (a, _) in gate.state.items() if a}
        unchecked += decided and not c.evaluate(current)
        ok, _ = gate.accept(Request(action, 1, versions, f"n{rep}"), action)
        gated += ok and not c.evaluate(current)
    write_csv("atomic_gate.csv", [dict(repetitions=reps, unchecked_unauthorized=unchecked,
                                       gate_unauthorized=gated)])


if __name__ == "__main__":
    e1()
    e2()
    graph_family()
    e4()
    atomic_gate()
