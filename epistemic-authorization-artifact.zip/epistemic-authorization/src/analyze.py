"""Aggregate statistics, bootstrap intervals and figures.

Reads ../results/*.csv, writes ../results/summary.json and ../figures/*.pdf.
Requires NumPy, pandas and Matplotlib.  Usage:  python3 src/analyze.py
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
FIG = os.path.join(HERE, "..", "figures")
os.makedirs(FIG, exist_ok=True)

BOOT = 5000
BOOT_SEED = 20260928
COLORS = {1: "#176b98", 2: "#1aa89c", 3: "#c8691f"}


def stratified_bootstrap(df, value, strata="n", reps=BOOT, seed=BOOT_SEED):
    """95% percentile interval of the mean, resampling within each stratum."""
    rng = np.random.default_rng(seed)
    groups = [g[value].to_numpy() for _, g in df.groupby(strata)]
    total = sum(len(g) for g in groups)
    stats = np.empty(reps)
    for b in range(reps):
        s = 0.0
        for g in groups:
            s += rng.choice(g, size=len(g), replace=True).sum()
        stats[b] = s / total
    lo, hi = np.percentile(stats, [2.5, 97.5])
    return float(df[value].mean()), float(lo), float(hi)


def main():
    out = {}
    e1 = pd.read_csv(os.path.join(RES, "e1_checks.csv"))
    out["e1"] = e1.set_index("check").to_dict(orient="index")

    e2 = pd.read_csv(os.path.join(RES, "e2_policies.csv"))
    ad = pd.read_csv(os.path.join(RES, "e3_adaptive.csv"))
    ab = pd.read_csv(os.path.join(RES, "e3_ablation.csv"))
    # adaptive savings are averaged within each circuit first
    ad_c = ad.groupby(["n", "index", "k"], as_index=False).saving.mean()

    synth = {}
    for k in (1, 2, 3):
        a = e2[e2.k == k]
        m, lo, hi = stratified_bootstrap(a, "saving_optimal")
        am, alo, ahi = stratified_bootstrap(ad_c[ad_c.k == k], "saving")
        both = a.cut_ms + a.opt_ms
        synth[k] = dict(
            optimal_saving=100 * m, optimal_ci=[100 * lo, 100 * hi],
            adaptive_saving=100 * am, adaptive_ci=[100 * alo, 100 * ahi],
            greedy_ratio_mean=float(a.greedy_ratio.mean()),
            greedy_ratio_max=float(a.greedy_ratio.max()),
            greedy_optimal_share=float((a.greedy_ratio == 1).mean()),
            false_safe=int(a.false_safe.sum()), policies=int(len(a)),
            median_cut_ms=float(a.cut_ms.median()), median_opt_ms=float(a.opt_ms.median()),
            p95_combined_ms=float(np.percentile(both, 95)))
    out["synthetic"] = synth

    out["adaptive"] = dict(
        decisions=int(len(ad)), matches=int(ad.match.sum()),
        authorized=int((ad.truth == "PERMIT").sum()), unauthorized=int((ad.truth == "DENY").sum()),
        mean_queries=float(ad.queries.mean()))
    out["ablation"] = dict(
        worlds=int(len(ab)), authorized=int(ab.authorized.sum()),
        snapshot_admits_unauthorized=int(ab.snapshot_admits_unauthorized.sum()),
        modal_admits_unauthorized=int(ab.modal_admits_unauthorized.sum()),
        modal_defers_authorized=int(ab.modal_defers_authorized.sum()),
        shortcut_admits_unauthorized=int(ab.shortcut_admits_unauthorized.sum()))

    g = pd.read_csv(os.path.join(RES, "graph_family.csv"))
    out["graph_family"] = dict(instances=int(len(g)), cuts_equal_edges=int(g.cuts_equal_edges.sum()),
                               greedy_ratio_mean=float(g.ratio.mean()), greedy_ratio_max=float(g.ratio.max()))

    s4 = pd.read_csv(os.path.join(RES, "e4_summary.csv"))
    e4 = pd.read_csv(os.path.join(RES, "e4_sites.csv"))
    sav = e4.groupby("suite")[["saving_k1", "saving_k2"]].mean() * 100
    out["e4"] = dict(
        task_classes=int(s4.task_classes.sum()), call_sites=int(s4.call_sites.sum()),
        mutating_sites=int(s4.mutating_sites.sum()),
        suites={r.suite: dict(mutating_sites=int(r.mutating_sites),
                              saving_k1=float(sav.loc[r.suite, "saving_k1"]),
                              saving_k2=float(sav.loc[r.suite, "saving_k2"]))
                for r in s4.itertuples()})
    out["atomic_gate"] = pd.read_csv(os.path.join(RES, "atomic_gate.csv")).iloc[0].to_dict()
    out["atomic_gate"] = {k: int(v) for k, v in out["atomic_gate"].items()}

    with open(os.path.join(RES, "summary.json"), "w") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2))

    # ------------------------------------------------------------------ figures
    plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False})

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 2.7))
    ks = [1, 2, 3]
    for key, label, col in (("optimal", "All-positive optimal plan", "#176b98"),
                            ("adaptive", "Adaptive actual responses", "#1aa89c")):
        m = [synth[k][f"{key}_saving"] for k in ks]
        ci = np.array([synth[k][f"{key}_ci"] for k in ks])
        ax1.errorbar(ks, m, yerr=[np.array(m) - ci[:, 0], ci[:, 1] - np.array(m)],
                     marker="o", capsize=3, color=col, label=label)
    ax1.set(xticks=ks, ylim=(0, 100), xlabel="Revocation budget k", ylabel="Query-cost reduction (%)")
    ax1.set_title("A  Cost relative to refreshing all sources", fontweight="bold")
    ax1.legend(frameon=True, fontsize=8, loc="lower left")
    for k in ks:
        r = np.sort(e2[e2.k == k].greedy_ratio.to_numpy())
        y = np.arange(1, len(r) + 1) / len(r)
        ax2.step(np.concatenate([[1.0], r]), np.concatenate([[0.0], y]), where="post",
                 color=COLORS[k], label=f"k = {k}")
    ax2.set(xlabel="Greedy cost / optimal cost", ylabel="Empirical cumulative fraction", ylim=(-0.02, 1.02))
    ax2.set_title("B  Approximation quality", fontweight="bold")
    ax2.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_cost_approx.pdf"))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 2.6))
    e2["combined"] = e2.cut_ms + e2.opt_ms
    for k in ks:
        med = e2[e2.k == k].groupby("n").combined.median()
        ax1.plot(med.index, med.values, marker="o", color=COLORS[k], label=f"k = {k}")
    ax1.set_yscale("log")
    ax1.set(xlabel="Source domains", ylabel="Median local computation (ms)")
    ax1.set_title("A  Cut construction + exact optimization", fontweight="bold")
    ax1.legend(fontsize=8)
    pct = [100 * synth[k]["false_safe"] / synth[k]["policies"] for k in ks]
    bars = ax2.bar([f"k = {k}" for k in ks], pct, color=[COLORS[k] for k in ks])
    for b, p in zip(bars, pct):
        ax2.text(b.get_x() + b.get_width() / 2, p + 1, f"{p:.1f}%", ha="center", fontsize=9)
    ax2.set(ylabel="False-safe classifications (%)", ylim=(0, max(pct) * 1.25))
    ax2.set_title("B  Invalid independence assumption", fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_timing_falsesafe.pdf"))
    print("figures written")


if __name__ == "__main__":
    main()
