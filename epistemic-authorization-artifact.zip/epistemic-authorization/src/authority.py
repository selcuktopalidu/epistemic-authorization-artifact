"""Epistemic authorization kernel.

Reference implementation for
  S. Topal, "Epistemic authorization for AI agents: knowing enough to act
  under bounded stale evidence".

Only the Python standard library is used.

Conventions
-----------
* Source domains are integers 0..n-1 (the circuit inputs).
* A circuit node is an input (id < n) or a threshold gate (id >= n).
  The most recently added gate is the output.
* Evidence: ``confirmed`` (T) and ``invalid`` (F) are sets of domains;
  every other *relevant* domain is stale (U).  ``k`` bounds the number of
  stale domains that may have been revoked without notice.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from itertools import combinations
import threading

INF = float("inf")


# ----------------------------------------------------------------------------
# Circuits
# ----------------------------------------------------------------------------
class Circuit:
    """Monotone threshold circuit over source domains."""

    def __init__(self, inputs):
        if isinstance(inputs, int):
            inputs = [f"x{i}" for i in range(inputs)]
        self.names = list(inputs)
        self.n = len(self.names)
        self.gates = []  # list of (children tuple, threshold)

    def add(self, children, threshold):
        children = tuple(children)
        if not children:
            raise ValueError("a gate needs at least one child")
        if not 1 <= threshold <= len(children):
            raise ValueError("threshold must satisfy 1 <= r <= m")
        if len(set(children)) != len(children):
            raise ValueError("duplicate inputs to one gate are not allowed")
        top = self.n + len(self.gates)
        for c in children:
            if not 0 <= c < top:
                raise ValueError("children must precede the gate (acyclic)")
        self.gates.append((children, threshold))
        return top

    # -- basic properties ---------------------------------------------------
    @property
    def output(self):
        if not self.gates:
            raise ValueError("circuit has no gates")
        return self.n + len(self.gates) - 1

    @property
    def size(self):
        """(|V|, |E|)."""
        return self.n + len(self.gates), sum(len(ch) for ch, _ in self.gates)

    def evaluate(self, available):
        """Iterative evaluation in topological order; ``available`` is a set."""
        val = [i in available for i in range(self.n)]
        for children, r in self.gates:
            val.append(sum(val[c] for c in children) >= r)
        return val[-1]

    def domains(self):
        """dom(v) for every node v (list of frozensets)."""
        dom = [frozenset([i]) for i in range(self.n)]
        for children, _ in self.gates:
            s = frozenset()
            for c in children:
                s |= dom[c]
            dom.append(s)
        return dom

    def relevant(self):
        """Domains on which the output depends syntactically."""
        return set(self.domains()[self.output])


def evaluate_recursive(circuit, available):
    """Independent oracle: threshold gates expanded into a disjunction of
    r-element conjunctions, evaluated recursively (used only for testing)."""
    memo = {}

    def val(v):
        if v < circuit.n:
            return v in available
        if v in memo:
            return memo[v]
        children, r = circuit.gates[v - circuit.n]
        res = any(all(val(c) for c in combo) for combo in combinations(children, r))
        memo[v] = res
        return res

    return val(circuit.output)


# ----------------------------------------------------------------------------
# Evidence helpers
# ----------------------------------------------------------------------------
def _split(circuit, confirmed, invalid, universe=None):
    T = set(confirmed or ())
    F = set(invalid or ())
    if T & F:
        raise ValueError("a domain cannot be both confirmed and invalid")
    base = set(range(circuit.n)) if universe is None else set(universe)
    U = sorted(base - T - F)
    return T, F, U


def worlds(circuit, k, confirmed=(), invalid=(), universe=None):
    """Enumerate the admissible worlds Omega(T, F, U, k)."""
    T, F, U = _split(circuit, confirmed, invalid, universe)
    Uset = set(U)
    for size in range(0, min(k, len(U)) + 1):
        for R in combinations(U, size):
            yield T | (Uset - set(R))


def knows(circuit, k, confirmed=(), invalid=(), universe=None):
    """K_{T,F,U,k} C: the circuit holds in every admissible world."""
    return all(circuit.evaluate(w) for w in worlds(circuit, k, confirmed, invalid, universe))


# ----------------------------------------------------------------------------
# Cuts, radius, verdicts
# ----------------------------------------------------------------------------
def minimal_cuts(circuit, k, confirmed=(), invalid=(), universe=None):
    """Algorithm 1: inclusion-minimal dangerous cuts of size <= k.

    Returns (cuts, evaluations).  ``cuts`` is a list of frozensets; the empty
    cut is returned alone when the nominal world is already unauthorized.
    ``universe`` defaults to all domains; experiments pass the relevant ones.
    """
    T, F, U = _split(circuit, confirmed, invalid, universe)
    Uset = set(U)
    evals = 1
    if not circuit.evaluate(T | Uset):
        return [frozenset()], evals
    cuts = []
    for size in range(1, min(k, len(U)) + 1):
        for R in combinations(U, size):
            Rs = frozenset(R)
            if any(D <= Rs for D in cuts):
                continue
            evals += 1
            if not circuit.evaluate(T | (Uset - Rs)):
                cuts.append(Rs)
    return cuts, evals


def radius(circuit, confirmed=(), invalid=(), universe=None, limit=None):
    """Conditional revocation radius rho(C;T,F) (capped search at ``limit``)."""
    T, F, U = _split(circuit, confirmed, invalid, universe)
    Uset = set(U)
    if not circuit.evaluate(T | Uset):
        return 0
    if circuit.evaluate(T):
        return INF
    top = len(U) if limit is None else min(limit, len(U))
    for size in range(1, top + 1):
        for R in combinations(U, size):
            if not circuit.evaluate(T | (Uset - set(R))):
                return size
    return INF if limit is None else limit + 1


def robust(circuit, k, confirmed=(), invalid=(), universe=None):
    """Permission judgment via the cut family (Theorem 5.3 / Lemma 5.7)."""
    cuts, _ = minimal_cuts(circuit, k, confirmed, invalid, universe)
    return not cuts


def verdict(circuit, k, confirmed=(), invalid=(), universe=None):
    cuts, _ = minimal_cuts(circuit, k, confirmed, invalid, universe)
    if not cuts:
        return "PERMIT"
    if frozenset() in cuts:
        return "DENY"
    return "DEFER"


# ----------------------------------------------------------------------------
# Refresh planning (weighted hitting set over the cut family)
# ----------------------------------------------------------------------------
def _cost(H, costs):
    return sum(costs[g] for g in H)


def greedy_refresh(cuts, costs):
    """Algorithm 3: weighted greedy hitting set (Chvatal)."""
    if frozenset() in cuts:
        raise ValueError("empty cut: no positive refresh can establish permission")
    H = set()
    residual = list(cuts)
    while residual:
        cand = set().union(*residual)
        g = max(sorted(cand), key=lambda x: (sum(1 for D in residual if x in D) / costs[x], -x))
        H.add(g)
        residual = [D for D in residual if g not in D]
    return frozenset(H)


def optimal_refresh(cuts, costs):
    """Algorithm 2: exact weighted hitting set by branch and bound.

    Starts from the greedy upper bound, branches on a smallest uncovered cut
    and memoizes, for each residual family, a valid lower bound on the cost of
    completing it.  Exact on completed searches.
    """
    if frozenset() in cuts:
        raise ValueError("empty cut: no positive refresh can establish permission")
    if not cuts:
        return frozenset()
    best_H = greedy_refresh(cuts, costs)
    best = [_cost(best_H, costs), best_H]
    memo = {}

    def search(H, cost, residual):
        if not residual:
            if cost < best[0]:
                best[0], best[1] = cost, frozenset(H)
            return 0
        key = frozenset(residual)
        lb = memo.get(key, 0)
        if cost + lb >= best[0]:
            return lb
        D = min(residual, key=lambda d: (len(d), sorted(d)))
        completion = INF
        for g in sorted(D, key=lambda x: (costs[x], x)):
            rest = [E for E in residual if g not in E]
            sub = search(H | {g}, cost + costs[g], rest)
            completion = min(completion, costs[g] + sub)
        new_lb = max(lb, completion) if completion < INF else lb
        memo[key] = new_lb
        return new_lb

    search(frozenset(), 0, list(cuts))
    return best[1]


def exhaustive_refresh(cuts, costs, universe):
    """Independent brute-force optimum (testing only)."""
    universe = sorted(universe)
    best, best_H = INF, None
    for size in range(len(universe) + 1):
        for H in combinations(universe, size):
            Hs = set(H)
            if all(Hs & D for D in cuts):
                c = _cost(Hs, costs)
                if c < best:
                    best, best_H = c, frozenset(Hs)
    return best_H


# ----------------------------------------------------------------------------
# Compositional shortcut (Proposition 7.1)
# ----------------------------------------------------------------------------
def compositional_radius(circuit, confirmed=(), invalid=()):
    """Radius computed gate by gate: sum of the m-r+1 smallest child radii."""
    T, F = set(confirmed), set(invalid)
    rad = []
    for i in range(circuit.n):
        rad.append(INF if i in T else 0 if i in F else 1)
    for children, r in circuit.gates:
        vals = sorted(rad[c] for c in children)
        rad.append(sum(vals[: len(children) - r + 1]))
    return rad[-1]


def source_disjoint(circuit):
    dom = circuit.domains()
    for children, _ in circuit.gates:
        seen = set()
        for c in children:
            if seen & dom[c]:
                return False
            seen |= dom[c]
    return True


def shortcut_robust(circuit, k, confirmed=(), invalid=(), checked=True):
    """Permission by the compositional shortcut.

    With ``checked=True`` the shortcut is used only when source disjointness
    holds and otherwise falls back to exact enumeration (the implementation's
    behaviour).  ``checked=False`` is the unsafe ablation.
    """
    if checked and not source_disjoint(circuit):
        return robust(circuit, k, confirmed, invalid)
    return compositional_radius(circuit, confirmed, invalid) > k


# ----------------------------------------------------------------------------
# Adaptive verification (Algorithm 4)
# ----------------------------------------------------------------------------
def adaptive_verify(circuit, k, costs, oracle, confirmed=(), invalid=(), universe=None,
                    planner=optimal_refresh):
    """Interleave planning and observation.

    ``oracle(g)`` returns True iff domain g is currently available.
    Returns (decision, queried list, total cost).
    """
    T, F, U = _split(circuit, confirmed, invalid, universe)
    U = set(U)
    queried, spent = [], 0
    while True:
        cuts, _ = minimal_cuts(circuit, k, T, F, universe=T | F | U)
        if not cuts:
            return "PERMIT", queried, spent
        if frozenset() in cuts:
            return "DENY", queried, spent
        H = planner(cuts, costs)
        g = min(sorted(H), key=lambda x: costs[x])
        queried.append(g)
        spent += costs[g]
        U.discard(g)
        if oracle(g):
            T.add(g)
        else:
            F.add(g)
            k -= 1
            if k < 0:
                raise RuntimeError("world violates the revocation bound")


# ----------------------------------------------------------------------------
# Atomic effect gate (reference acceptance boundary, Section 7.3)
# ----------------------------------------------------------------------------
@dataclass
class Request:
    action: tuple
    policy_epoch: int
    source_versions: dict
    nonce: str


@dataclass
class AtomicGate:
    """Process-local acceptance point.

    Accepts a request only if the policy epoch and every bound source version
    are current, the nonce is fresh, and the circuit holds in the *current*
    nominal state (complete check under a lock).
    """
    circuit: Circuit
    policy_epoch: int
    state: dict  # domain -> (available: bool, version: int)
    used_nonces: set = field(default_factory=set)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def revoke(self, g):
        with self.lock:
            avail, ver = self.state[g]
            self.state[g] = (False, ver + 1)

    def snapshot_versions(self):
        with self.lock:
            return {g: v for g, (_, v) in self.state.items()}

    def accept(self, req: Request, bound_action: tuple):
        with self.lock:
            if req.action != bound_action:
                return False, "action substitution"
            if req.policy_epoch != self.policy_epoch:
                return False, "policy epoch changed"
            if req.nonce in self.used_nonces:
                return False, "replay"
            for g, v in req.source_versions.items():
                if self.state[g][1] != v:
                    return False, "stale source version"
            current = {g for g, (a, _) in self.state.items() if a}
            if not self.circuit.evaluate(current):
                return False, "not authorized now"
            self.used_nonces.add(req.nonce)
            return True, "accepted"
