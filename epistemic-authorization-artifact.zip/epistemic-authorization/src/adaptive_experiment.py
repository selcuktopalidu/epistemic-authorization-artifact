"""Experiment E3: adaptive verification with actual replies in simulated
worlds, plus the unrefreshed-snapshot / modal-gate / independence ablation
on a separate world sample.  Usage:  python3 src/adaptive_experiment.py
"""
import csv
import os
import random

from authority import adaptive_verify, compositional_radius, robust
from generators import BUDGETS, e2_policies

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
os.makedirs(RES, exist_ok=True)


def draw_world(rng, rel, k):
    """Revocation cardinality uniform on 0..k, then domains uniformly."""
    size = rng.randint(0, k)
    revoked = set(rng.sample(sorted(rel), size))
    return set(rel) - revoked, revoked


def write_csv(name, rows):
    with open(os.path.join(RES, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"  wrote {name} ({len(rows)} rows)")


def main():
    adaptive_rows, ablation_rows = [], []
    for n, i, seed, c, costs in e2_policies():
        rel = c.relevant()
        total = sum(costs[g] for g in rel)
        for k in BUDGETS:
            # --- adaptive sample: 10 worlds per condition
            rng = random.Random(f"adaptive-{seed}-{k}")
            for w in range(10):
                W, revoked = draw_world(rng, rel, k)
                truth = "PERMIT" if c.evaluate(W) else "DENY"
                dec, queried, spent = adaptive_verify(c, k, costs, lambda g: g in W, universe=rel)
                adaptive_rows.append(dict(
                    n=n, index=i, seed=seed, k=k, world=w, revoked=len(revoked),
                    truth=truth, decision=dec, match=int(dec == truth),
                    queries=len(queried), cost=spent, refresh_all_cost=total,
                    saving=1 - spent / total))
            # --- ablation sample: 20 worlds per condition
            rng = random.Random(f"ablation-{seed}-{k}")
            modal_permit = robust(c, k, universe=rel)
            shortcut_permit = compositional_radius(c) > k
            for w in range(20):
                W, revoked = draw_world(rng, rel, k)
                auth = c.evaluate(W)
                ablation_rows.append(dict(
                    n=n, index=i, seed=seed, k=k, world=w, revoked=len(revoked),
                    authorized=int(auth),
                    snapshot_admits_unauthorized=int(not auth),  # stale snapshot always accepts
                    modal_admits_unauthorized=int(modal_permit and not auth),
                    modal_defers_authorized=int((not modal_permit) and auth),
                    shortcut_admits_unauthorized=int(shortcut_permit and not auth)))
    write_csv("e3_adaptive.csv", adaptive_rows)
    write_csv("e3_ablation.csv", ablation_rows)


if __name__ == "__main__":
    main()
